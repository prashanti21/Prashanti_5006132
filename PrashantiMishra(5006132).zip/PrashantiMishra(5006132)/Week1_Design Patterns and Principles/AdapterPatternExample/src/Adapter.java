public class Adapter {

    
    public interface PaymentProcessor {
        void processPayment(double amount);
    }

   
    public static class PayPal {
        public void makePayment(double amount) {
            System.out.println("Processing payment with PayPal: $" + amount);
        }
    }

    public static class Stripe {
        public void charge(double amount) {
            System.out.println("Charging with Stripe: $" + amount);
        }
    }

    public static class Square {
        public void submitPayment(double amount) {
            System.out.println("Submitting payment with Square: $" + amount);
        }
    }


    public static class PayPalAdapter implements PaymentProcessor {
        private PayPal payPal;

        public PayPalAdapter(PayPal payPal) {
            this.payPal = payPal;
        }

     
        public void processPayment(double amount) {
            payPal.makePayment(amount);
        }
    }

    public static class StripeAdapter implements PaymentProcessor {
        private Stripe stripe;

        public StripeAdapter(Stripe stripe) {
            this.stripe = stripe;
        }

        
        public void processPayment(double amount) {
            stripe.charge(amount);
        }
    }

    public static class SquareAdapter implements PaymentProcessor {
        private Square square;

        public SquareAdapter(Square square) {
            this.square = square;
        }

       
        public void processPayment(double amount) {
            square.submitPayment(amount);
        }
    }

   
    public static void main(String[] args) {
       
        PayPal payPal = new PayPal();
        Stripe stripe = new Stripe();
        Square square = new Square();

        
        PaymentProcessor payPalProcessor = new PayPalAdapter(payPal);
        PaymentProcessor stripeProcessor = new StripeAdapter(stripe);
        PaymentProcessor squareProcessor = new SquareAdapter(square);


        System.out.println("Testing PayPal:");
        payPalProcessor.processPayment(100.0);

        System.out.println("Testing Stripe:");
        stripeProcessor.processPayment(200.0);

        System.out.println("Testing Square:");
        squareProcessor.processPayment(300.0);
    }
}