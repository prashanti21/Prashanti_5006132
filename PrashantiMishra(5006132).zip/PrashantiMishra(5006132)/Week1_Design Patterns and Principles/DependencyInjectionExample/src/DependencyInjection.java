public class DependencyInjection {

    public interface CustomerRepository {
        String findCustomerById(String id);
    }

    public static class CustomerRepositoryImpl implements CustomerRepository {
        @Override
        public String findCustomerById(String id) {
            return "Customer with ID: " + id;
        }
    }

    public static class CustomerService {
        private CustomerRepository repository;

        public CustomerService(CustomerRepository repository) {
            this.repository = repository;
        }

        public String getCustomer(String id) {
            return repository.findCustomerById(id);
        }
    }

    public static void main(String[] args) {
        CustomerRepository repository = new CustomerRepositoryImpl();
        CustomerService service = new CustomerService(repository);

        String customerDetails = service.getCustomer("12345");
        System.out.println(customerDetails);
    }
}