public class ProxyPattern {

    public interface Image {
        void display();
    }

    public static class RealImage implements Image {
        private String filename;

        public RealImage(String filename) {
            this.filename = filename;
            loadFromServer();
        }

        private void loadFromServer() {
            System.out.println("Loading image: " + filename);
        }

        @Override
        public void display() {
            System.out.println("Displaying image: " + filename);
        }
    }

    public static class ProxyImage implements Image {
        private RealImage realImage;
        private String filename;
        private boolean isImageLoaded;

        public ProxyImage(String filename) {
            this.filename = filename;
            this.isImageLoaded = false;
        }

        @Override
        public void display() {
            if (!isImageLoaded) {
                realImage = new RealImage(filename);
                isImageLoaded = true;
            }
            realImage.display();
        }
    }

    public static void main(String[] args) {
        Image image1 = new ProxyImage("photo1.jpg");
        Image image2 = new ProxyImage("photo2.jpg");

        image1.display();
        image1.display();  // Should use cached image
        image2.display();
        image2.display();  // Should use cached image
    }
}
