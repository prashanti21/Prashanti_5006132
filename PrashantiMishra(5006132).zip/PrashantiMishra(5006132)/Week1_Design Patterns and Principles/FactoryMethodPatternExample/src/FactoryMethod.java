public class FactoryMethod {

    
    interface Document {
        void open();
        void close();
    }

    static class WordDocument implements Document {
        
        public void open() {
            System.out.println("Opening Word Document.");
        }

    
        public void close() {
            System.out.println("Closing Word Document.");
        }
    }

    static class PdfDocument implements Document {
       
        public void open() {
            System.out.println("Opening PDF Document.");
        }

      
        public void close() {
            System.out.println("Closing PDF Document.");
        }
    }

    static class ExcelDocument implements Document {
     
        public void open() {
            System.out.println("Opening Excel Document.");
        }

      
        public void close() {
            System.out.println("Closing Excel Document.");
        }
    }

 
    abstract static class DocumentFactory {
        public abstract Document createDocument();
    }

    static class WordDocumentFactory extends DocumentFactory {
        
        public Document createDocument() {
            return new WordDocument();
        }
    }

    static class PdfDocumentFactory extends DocumentFactory {
       
        public Document createDocument() {
            return new PdfDocument();
        }
    }

    static class ExcelDocumentFactory extends DocumentFactory {
    
        public Document createDocument() {
            return new ExcelDocument();
        }
    }

 
    public static void main(String[] args) {
     
        DocumentFactory wordFactory = new WordDocumentFactory();
        DocumentFactory pdfFactory = new PdfDocumentFactory();
        DocumentFactory excelFactory = new ExcelDocumentFactory();

        
        Document wordDoc = wordFactory.createDocument();
        Document pdfDoc = pdfFactory.createDocument();
        Document excelDoc = excelFactory.createDocument();

      
        wordDoc.open();
        wordDoc.close();

        pdfDoc.open();
        pdfDoc.close();

        excelDoc.open();
        excelDoc.close();
    }
}

