public class EmailNotifier {

    public interface Notifier {
        void send(String message);
    }

    public static class EmailNotifierImpl implements Notifier {
        @Override
        public void send(String message) {
            System.out.println("Sending email with message: " + message);
        }
    }

    public static abstract class NotifierDecorator implements Notifier {
        protected Notifier notifier;

        public NotifierDecorator(Notifier notifier) {
            this.notifier = notifier;
        }

        @Override
        public void send(String message) {
            notifier.send(message);
        }
    }

    public static class SMSNotifierDecorator extends NotifierDecorator {
        public SMSNotifierDecorator(Notifier notifier) {
            super(notifier);
        }

        @Override
        public void send(String message) {
            super.send(message);
            sendSMS(message);
        }

        private void sendSMS(String message) {
            System.out.println("Sending SMS with message: " + message);
        }
    }

    public static class SlackNotifierDecorator extends NotifierDecorator {
        public SlackNotifierDecorator(Notifier notifier) {
            super(notifier);
        }

        @Override
        public void send(String message) {
            super.send(message);
            sendSlack(message);
        }

        private void sendSlack(String message) {
            System.out.println("Sending Slack message with: " + message);
        }
    }

    public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifierImpl();
        Notifier smsEmailNotifier = new SMSNotifierDecorator(emailNotifier);
        smsEmailNotifier.send("Hello via Email and SMS!");
        Notifier slackSmsEmailNotifier = new SlackNotifierDecorator(smsEmailNotifier);
        slackSmsEmailNotifier.send("Hello via Email, SMS, and Slack!");
    }
}
