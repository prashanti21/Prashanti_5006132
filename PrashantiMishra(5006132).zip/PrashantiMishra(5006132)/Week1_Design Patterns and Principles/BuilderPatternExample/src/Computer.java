
public class Computer {

    
    
        private final String CPU;
        private final String RAM;
        private final String storage;
        private final boolean hasGraphicsCard;
        private final boolean hasWiFi;

        private Computer(Builder builder) {
            this.CPU = builder.CPU;
            this.RAM = builder.RAM;
            this.storage = builder.storage;
            this.hasGraphicsCard = builder.hasGraphicsCard;
            this.hasWiFi = builder.hasWiFi;
        }

       
        public String toString() {
            return "Computer{" +
                    "CPU='" + CPU + '\'' +
                    ", RAM='" + RAM + '\'' +
                    ", Storage='" + storage + '\'' +
                    ", Graphics Card=" + (hasGraphicsCard ? "Yes" : "No") +
                    ", WiFi=" + (hasWiFi ? "Yes" : "No") +
                    '}';
        }

        
        public static class Builder {
            private String CPU;
            private String RAM;
            private String storage;
            private boolean hasGraphicsCard;
            private boolean hasWiFi;

            public Builder setCPU(String CPU) {
                this.CPU = CPU;
                return this;
            }

            public Builder setRAM(String RAM) {
                this.RAM = RAM;
                return this;
            }

            public Builder setStorage(String storage) {
                this.storage = storage;
                return this;
            }

            public Builder setHasGraphicsCard(boolean hasGraphicsCard) {
                this.hasGraphicsCard = hasGraphicsCard;
                return this;
            }

            public Builder setHasWiFi(boolean hasWiFi) {
                this.hasWiFi = hasWiFi;
                return this;
            }

            public Computer build() {
                return new Computer(this);
            }
        }
    

  
    public static void main(String[] args) {
       
        Computer basicComputer = new Computer.Builder()
                .setCPU("Intel i5")
                .setRAM("8GB")
                .setStorage("256GB SSD")
                .build();

        
        Computer highEndComputer = new Computer.Builder()
                .setCPU("Intel i9")
                .setRAM("32GB")
                .setStorage("1TB SSD")
                .setHasGraphicsCard(true)
                .setHasWiFi(true)
                .build();

      
        System.out.println("Basic Computer Configuration:");
        System.out.println(basicComputer);

        System.out.println("\nHigh-End Computer Configuration:");
        System.out.println(highEndComputer);
    }
}
