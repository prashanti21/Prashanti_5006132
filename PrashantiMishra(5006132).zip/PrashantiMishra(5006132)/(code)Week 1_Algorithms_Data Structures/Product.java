package inventorymanagement;

import java.util.HashMap;
import java.util.Map;

public class Product {

    

        private int productId;
        private String productName;
        private int quantity;
        private double price;

        public Product(int productId, String productName, int quantity, double price)
        {
            this.productId = productId;
            this.productName = productName;
            this.quantity = quantity;
            this.price = price;
        }

        public int getProductId() 
        {
            return productId;
        }

        public String getProductName()
        {
            return productName;
        }

        public int getQuantity()
        {
            return quantity;
        }

        public double getPrice() 
        {
            return price;
        }

        public void setQuantity(int quantity) 
        {
            this.quantity = quantity;
        }

        public void setPrice(double price)
        {
            this.price = price;
        }

       
        public String toString() {
            return "Product{id=" + productId + ", name='" + productName + "', quantity=" + quantity + ", price=" + price + "}";
        }
    

    private Map<Integer, Product> inventory;

    public Product() {
        this.inventory = new HashMap<>();
    }

    public void addProduct(Product product) {
        if (inventory.containsKey(product.getProductId())) {
            System.out.println("Product with ID " + product.getProductId() + " already exists.");
        } else {
            inventory.put(product.getProductId(), product);
            System.out.println("Product " + product.getProductName() + " added to inventory.");
        }
    }

    public void updateProduct(Product product) {
        if (inventory.containsKey(product.getProductId())) {
            inventory.put(product.getProductId(), product);
            System.out.println("Product " + product.getProductName() + " updated in inventory.");
        } else {
            System.out.println("Product with ID " + product.getProductId() + " does not exist.");
        }
    }

    public void deleteProduct(int productId) {
        if (inventory.containsKey(productId)) {
            inventory.remove(productId);
            System.out.println("Product with ID " + productId + " deleted from inventory.");
        } else {
            System.out.println("Product with ID " + productId + " does not exist.");
        }
    }

    public void displayInventory() {
        for (Product product : inventory.values()) {
            System.out.println(product);
        }
    }

    public static void main(String[] args) {
        Product ims = new Product();

        
        Product product1 = new Product(1, "Laptop", 10, 899.98);
        Product product2 = new Product(2, "Television", 50, 900.95);

        ims.addProduct(product1);
        ims.addProduct(product2);

        
        Product product1Updated = new Product(1, "Laptop", 15, 999.99);
        ims.updateProduct(product1Updated);

        
        ims.deleteProduct(2);

        
        ims.displayInventory();
    }
}
