package com.example.bookstoreapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
