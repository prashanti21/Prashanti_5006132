package com.employee.EmployeeManagementSystem.dto;

public class EmployeeDTO {

}
