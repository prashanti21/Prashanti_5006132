package com.employee.EmployeeManagementSystem.projection;

public interface DepartmentProjection {
    
    Long getId();
    
    String getName();
}
