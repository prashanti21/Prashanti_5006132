package com.book.services;

import com.book.model.Book;
import com.book.exception.BookNotFoundException;
import com.book.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    // Create a new book
    public Book saveBook(Book book) {
        return bookRepository.save(book);
    }

    // Find a book by ID
    public Book findBookById(Long id) {
        return bookRepository.findById(id)
                .orElseThrow(() -> new BookNotFoundException(id));
    }

    // Find all books
    public List<Book> findAllBooks() {
        return bookRepository.findAll();
    }

    // Update a book by ID
    public Book updateBook(Long id, Book book) {
        if (!bookRepository.existsById(id)) {
            throw new BookNotFoundException(id);
        }
        book.setId(id);
        return bookRepository.save(book);
    }

    // Delete a book by ID
    public void deleteBook(Long id) {
        if (!bookRepository.existsById(id)) {
            throw new BookNotFoundException(id);
        }
        bookRepository.deleteById(id);
    }
}
