package com.book.controller;

import com.book.dto.BookDTO;
import com.book.assembler.BookResourceAssembler;
import com.book.model.Book;
import com.book.services.BookService;
import com.book.mapper.BookMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @Autowired
    private BookResourceAssembler bookResourceAssembler;

    @Autowired
    private BookMapper bookMapper;
    
    @PostMapping
    public ResponseEntity<EntityModel<BookDTO>> createBook(@Valid @RequestBody BookDTO bookDTO) {
        Book book = bookMapper.bookDTOToBook(bookDTO);
        Book savedBook = bookService.saveBook(book);
        BookDTO savedBookDTO = bookMapper.bookToBookDTO(savedBook);
        EntityModel<BookDTO> resource = bookResourceAssembler.toModel(savedBookDTO);
        return new ResponseEntity<>(resource, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<BookDTO>> getBookById(@PathVariable Long id) {
        Book book = bookService.findBookById(id);
        BookDTO bookDTO = bookMapper.bookToBookDTO(book);
        EntityModel<BookDTO> resource = bookResourceAssembler.toModel(bookDTO);
        return new ResponseEntity<>(resource, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<EntityModel<BookDTO>>> getAllBooks() {
        List<Book> books = bookService.findAllBooks();
        List<EntityModel<BookDTO>> bookResources = books.stream()
                .map(book -> bookMapper.bookToBookDTO(book))
                .map(bookDTO -> bookResourceAssembler.toModel(bookDTO))
                .collect(Collectors.toList());
        return new ResponseEntity<>(bookResources, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<EntityModel<BookDTO>> updateBook(@PathVariable Long id, @Valid @RequestBody BookDTO bookDTO) {
        Book book = bookMapper.bookDTOToBook(bookDTO);
        Book updatedBook = bookService.updateBook(id, book);
        BookDTO updatedBookDTO = bookMapper.bookToBookDTO(updatedBook);
        EntityModel<BookDTO> resource = bookResourceAssembler.toModel(updatedBookDTO);
        return new ResponseEntity<>(resource, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        bookService.deleteBook(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
