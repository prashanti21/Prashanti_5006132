package com.book.controller;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.*;

import com.book.controller.BookController;
import com.book.dto.BookDTO;
import com.book.services.BookService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@WebMvcTest(BookController.class)
public class BookControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private BookService bookService;

    @InjectMocks
    private BookController bookController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(bookController).build();
    }

    @Test
    public void testGetBookById() throws Exception {
        BookDTO book = new BookDTO(1L, "Effective Java", "Joshua Bloch", 45.00, "9780134685991");

        when(bookService.findBookById(1L)).thenReturn(book);

        mockMvc.perform(get("/books/1")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Effective Java"))
                .andExpect(jsonPath("$.author").value("Joshua Bloch"))
                .andExpect(jsonPath("$.price").value(45.00))
                .andExpect(jsonPath("$.isbn").value("9780134685991"))
                .andDo(print());

        verify(bookService, times(1)).findBookById(1L);
    }

    @Test
    public void testGetBookById_NotFound() throws Exception {
        when(bookService.findBookById(1L)).thenThrow(new BookNotFoundException("Book not found"));

        mockMvc.perform(get("/books/1")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string("Book not found"))
                .andDo(print());

        verify(bookService, times(1)).findBookById(1L);
    }

    @Test
    public void testCreateBook() throws Exception {
        BookDTO book = new BookDTO(null, "Effective Java", "Joshua Bloch", 45.00, "9780134685991");

        when(bookService.saveBook(any(BookDTO.class))).thenReturn(book);

        mockMvc.perform(post("/books")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"title\":\"Effective Java\",\"author\":\"Joshua Bloch\",\"price\":45.00,\"isbn\":\"9780134685991\"}")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.title").value("Effective Java"))
                .andExpect(jsonPath("$.author").value("Joshua Bloch"))
                .andExpect(jsonPath("$.price").value(45.00))
                .andExpect(jsonPath("$.isbn").value("9780134685991"))
                .andDo(print());

        verify(bookService, times(1)).saveBook(any(BookDTO.class));
    }

    @Test
    public void testUpdateBook() throws Exception {
        BookDTO book = new BookDTO(1L, "Effective Java", "Joshua Bloch", 45.00, "9780134685991");

        when(bookService.updateBook(anyLong(), any(BookDTO.class))).thenReturn(book);

        mockMvc.perform(put("/books/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"title\":\"Effective Java\",\"author\":\"Joshua Bloch\",\"price\":45.00,\"isbn\":\"9780134685991\"}")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Effective Java"))
                .andExpect(jsonPath("$.author").value("Joshua Bloch"))
                .andExpect(jsonPath("$.price").value(45.00))
                .andExpect(jsonPath("$.isbn").value("9780134685991"))
                .andDo(print());

        verify(bookService, times(1)).updateBook(eq(1L), any(BookDTO.class));
    }

    @Test
    public void testDeleteBook() throws Exception {
        doNothing().when(bookService).deleteBook(1L);

        mockMvc.perform(delete("/books/1")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent())
                .andDo(print());

        verify(bookService, times(1)).deleteBook(1L);
    }
}

