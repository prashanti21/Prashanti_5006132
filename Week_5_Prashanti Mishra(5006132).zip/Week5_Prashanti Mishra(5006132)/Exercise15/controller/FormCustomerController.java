package com.book.controller;

import org.springframework.web.bind.annotation.*;

import com.book.model.Customer;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/form-customers")
public class FormCustomerController {

    private List<Customer> customers = new ArrayList<>();

    @PostMapping
    public Customer registerCustomer(@ModelAttribute Customer customer) {
        customers.add(customer);
        return customer;
    }

    @GetMapping
    public List<Customer> getAllCustomers() {
        return customers;
    }
}
